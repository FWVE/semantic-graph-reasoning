SemGraph-Bench

450 questions across seven source graphs and nine structural families.
queries.csv: public questions and anchors.
gold.json: complete reference answers for offline evaluation.
benchmarks/resources/: frozen structures, source text and graph provenance.

Download the full source graphs with python benchmarks/download.py --download.
Source text retains its upstream terms.
