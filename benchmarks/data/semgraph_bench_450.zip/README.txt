SemGraph-Bench — 450-query benchmark

queries.csv: public questions, graph domain and public anchors.
gold.json: private complete answers and certificates; offline evaluation only.
audit.json: verified quotas, full-answer validation and lexical/decoy diagnostics.
benchmarks/resources/: frozen structures, relevant full original texts, aliases and source provenance.
benchmarks/ready/: complete per-query evidence, author provenance and public audits.
benchmarks/catalog.json and config.json: the policies used for certification.

All 450 questions and complete reference answers are included.
The original audit records the following remaining admission check:
the required semantic near-miss and hard-decoy admission has not been recorded.
The logical counterfactuals and lexical scores in audit.json are diagnostics only.
No second semantic review was run, and no saved judgment was changed for packaging.

Recompute in the original repository with: python -B -m query_generation verify
Rebuild this delivery with: python -B -m query_generation.delivery
Original full graph datasets are not duplicated in this archive; their pinned
locations and hashes are in benchmarks/resources/sources.json.
No credentials, retired content, failed attempts or raw provider logs are included.
